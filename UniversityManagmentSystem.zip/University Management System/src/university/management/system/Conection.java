package university.management.system;

import java.sql.*;

public class Conection {
    
    Connection c;
    Statement s;

    Conection () {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql:///universitymanagementsystemzim", "root", "32355152");
            s = c.createStatement();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
